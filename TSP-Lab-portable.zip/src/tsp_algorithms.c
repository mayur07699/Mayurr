#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_N 9
#define MAX_EVENTS 30000
#define INF 1.0e100

enum {
  EV_SEED,
  EV_EXPAND,
  EV_PRUNE,
  EV_CANDIDATE,
  EV_BEST,
  EV_DONE,
  EV_BASE,
  EV_TRANSITION,
  EV_FINISH,
  EV_SOLUTION
};

typedef struct {
  const char *name;
  double x;
  double y;
} City;

typedef struct {
  int type;
  int len;
  int path[MAX_N + 1];
  double cost;
  double bound;
  int from;
  int to;
  int updated;
} Event;

typedef struct {
  int n;
  int event_count;
  Event events[MAX_EVENTS];
  int expanded;
  int pruned;
  int transitions;
  int states;
  double best_distance;
  int best_route[MAX_N + 1];
  int best_route_len;
  double elapsed_ms;
  unsigned long workspace_bytes;
} Run;

typedef struct {
  int n;
  int path[MAX_N];
  int best_path[MAX_N];
  unsigned char visited[MAX_N];
  double best_distance;
  Run *run;
} BranchContext;

static const City CITIES[MAX_N] = {
  {"Arcadia", 105.0, 315.0},
  {"Solis",   245.0, 140.0},
  {"Tern",    390.0, 280.0},
  {"Vela",    545.0, 120.0},
  {"Orin",    715.0, 225.0},
  {"Luma",    845.0, 390.0},
  {"Pavo",    665.0, 460.0},
  {"Nera",    435.0, 425.0},
  {"Kora",    225.0, 475.0}
};

static double distance_table[MAX_N][MAX_N];
static Run branch_run;
static Run dp_run;

static const char *event_name(int type) {
  switch (type) {
    case EV_SEED: return "seed";
    case EV_EXPAND: return "expand";
    case EV_PRUNE: return "prune";
    case EV_CANDIDATE: return "candidate";
    case EV_BEST: return "best";
    case EV_DONE: return "done";
    case EV_BASE: return "base";
    case EV_TRANSITION: return "transition";
    case EV_FINISH: return "finish";
    case EV_SOLUTION: return "solution";
    default: return "unknown";
  }
}

static void push_event(Run *run, int type, const int *path, int len,
                       double cost, double bound, int from, int to,
                       int updated) {
  if (run->event_count >= MAX_EVENTS) {
    fprintf(stderr, "trace event limit exceeded\n");
    exit(2);
  }
  Event *event = &run->events[run->event_count++];
  event->type = type;
  event->len = len;
  for (int i = 0; i < len && i <= MAX_N; i++) event->path[i] = path[i];
  event->cost = cost;
  event->bound = bound;
  event->from = from;
  event->to = to;
  event->updated = updated;
}

static double route_cost(const int *route, int n) {
  double total = 0.0;
  for (int i = 1; i < n; i++) total += distance_table[route[i - 1]][route[i]];
  return total + distance_table[route[n - 1]][route[0]];
}

static double mst_cost(const int *remaining, int count) {
  if (count <= 1) return 0.0;
  double nearest[MAX_N];
  unsigned char used[MAX_N] = {0};
  for (int i = 0; i < count; i++) nearest[i] = INF;
  nearest[0] = 0.0;
  double total = 0.0;

  for (int step = 0; step < count; step++) {
    int selected = -1;
    for (int i = 0; i < count; i++) {
      if (!used[i] && (selected < 0 || nearest[i] < nearest[selected])) selected = i;
    }
    used[selected] = 1;
    total += nearest[selected];
    for (int i = 0; i < count; i++) {
      if (!used[i]) {
        double edge = distance_table[remaining[selected]][remaining[i]];
        if (edge < nearest[i]) nearest[i] = edge;
      }
    }
  }
  return total;
}

/* A valid lower bound: current-to-unvisited + an MST of unvisited
   + unvisited-to-start. Every completion must pay all three pieces. */
static double lower_bound(const BranchContext *ctx, int last, double cost) {
  int remaining[MAX_N];
  int count = 0;
  double from_last = INF;
  double to_start = INF;
  for (int city = 1; city < ctx->n; city++) {
    if (!ctx->visited[city]) {
      remaining[count++] = city;
      if (distance_table[last][city] < from_last) from_last = distance_table[last][city];
      if (distance_table[0][city] < to_start) to_start = distance_table[0][city];
    }
  }
  if (count == 0) return cost + distance_table[last][0];
  return cost + from_last + mst_cost(remaining, count) + to_start;
}

static void branch_search(BranchContext *ctx, int last, double cost, int depth) {
  Run *run = ctx->run;
  run->expanded++;

  if (depth == ctx->n) {
    double completed = cost + distance_table[last][0];
    int full[MAX_N + 1];
    for (int i = 0; i < ctx->n; i++) full[i] = ctx->path[i];
    full[ctx->n] = 0;
    push_event(run, EV_CANDIDATE, full, ctx->n + 1, completed, -1.0,
               last, 0, 0);
    if (completed + 1e-9 < ctx->best_distance) {
      ctx->best_distance = completed;
      for (int i = 0; i < ctx->n; i++) ctx->best_path[i] = ctx->path[i];
      int best[MAX_N + 1];
      for (int i = 0; i < ctx->n; i++) best[i] = ctx->path[i];
      best[ctx->n] = 0;
      push_event(run, EV_BEST, best, ctx->n + 1, completed, -1.0,
                 last, 0, 1);
    }
    return;
  }

  double bound = lower_bound(ctx, last, cost);
  push_event(run, EV_EXPAND, ctx->path, depth, cost, bound, -1, last, 0);
  if (bound >= ctx->best_distance - 1e-9) {
    run->pruned++;
    push_event(run, EV_PRUNE, ctx->path, depth, cost, bound, -1, last, 0);
    return;
  }

  int candidates[MAX_N];
  int count = 0;
  for (int city = 1; city < ctx->n; city++) {
    if (!ctx->visited[city]) candidates[count++] = city;
  }
  for (int i = 0; i < count; i++) {
    for (int j = i + 1; j < count; j++) {
      if (distance_table[last][candidates[j]] < distance_table[last][candidates[i]]) {
        int swap = candidates[i];
        candidates[i] = candidates[j];
        candidates[j] = swap;
      }
    }
  }

  for (int i = 0; i < count; i++) {
    int city = candidates[i];
    ctx->visited[city] = 1;
    ctx->path[depth] = city;
    branch_search(ctx, city, cost + distance_table[last][city], depth + 1);
    ctx->visited[city] = 0;
  }
}

static void solve_branch_bound(int n, Run *run) {
  memset(run, 0, sizeof(*run));
  run->n = n;
  BranchContext ctx;
  memset(&ctx, 0, sizeof(ctx));
  ctx.n = n;
  ctx.run = run;

  clock_t started = clock();

  /* A nearest-neighbor tour gives the search a useful first upper bound. */
  ctx.path[0] = 0;
  ctx.visited[0] = 1;
  for (int depth = 1; depth < n; depth++) {
    int last = ctx.path[depth - 1];
    int nearest = -1;
    for (int city = 1; city < n; city++) {
      if (!ctx.visited[city] &&
          (nearest < 0 || distance_table[last][city] < distance_table[last][nearest])) {
        nearest = city;
      }
    }
    ctx.path[depth] = nearest;
    ctx.visited[nearest] = 1;
  }
  ctx.best_distance = route_cost(ctx.path, n);
  for (int i = 0; i < n; i++) ctx.best_path[i] = ctx.path[i];

  int seed[MAX_N + 1];
  for (int i = 0; i < n; i++) seed[i] = ctx.best_path[i];
  seed[n] = 0;
  push_event(run, EV_SEED, seed, n + 1, ctx.best_distance, -1.0, -1, -1, 1);

  memset(ctx.visited, 0, sizeof(ctx.visited));
  ctx.visited[0] = 1;
  ctx.path[0] = 0;
  branch_search(&ctx, 0, 0.0, 1);

  run->best_distance = ctx.best_distance;
  run->best_route_len = n + 1;
  for (int i = 0; i < n; i++) run->best_route[i] = ctx.best_path[i];
  run->best_route[n] = 0;
  run->workspace_bytes = (unsigned long)n *
    (2UL * sizeof(int) + sizeof(unsigned char) + 32UL);
  push_event(run, EV_DONE, run->best_route, n + 1, ctx.best_distance,
             -1.0, -1, -1, 1);

  clock_t finished = clock();
  run->elapsed_ms = 1000.0 * (double)(finished - started) / (double)CLOCKS_PER_SEC;
}

static int popcount(unsigned int value) {
  int count = 0;
  while (value) {
    count += (int)(value & 1U);
    value >>= 1U;
  }
  return count;
}

static int reconstruct_path(int mask, int city, int n,
                            const int *parent, int *out) {
  int reverse[MAX_N];
  int length = 0;
  int current = city;
  int remaining_mask = mask;
  while (current != 0 && length < MAX_N) {
    reverse[length++] = current;
    int previous = parent[remaining_mask * n + current];
    remaining_mask ^= 1 << (current - 1);
    current = previous;
  }
  out[0] = 0;
  for (int i = 0; i < length; i++) out[i + 1] = reverse[length - 1 - i];
  return length + 1;
}

static void solve_dynamic_programming(int n, Run *run) {
  memset(run, 0, sizeof(*run));
  run->n = n;
  int cities_after_start = n - 1;
  int state_count = 1 << cities_after_start;
  size_t cells = (size_t)state_count * (size_t)n;
  double *dp = (double *)malloc(cells * sizeof(double));
  int *parent = (int *)malloc(cells * sizeof(int));
  if (!dp || !parent) {
    fprintf(stderr, "unable to allocate DP tables\n");
    exit(2);
  }

  clock_t started = clock();
  for (size_t i = 0; i < cells; i++) {
    dp[i] = INF;
    parent[i] = -1;
  }

  for (int city = 1; city < n; city++) {
    int mask = 1 << (city - 1);
    dp[(size_t)mask * n + city] = distance_table[0][city];
    parent[(size_t)mask * n + city] = 0;
    run->states++;
    int path[2] = {0, city};
    push_event(run, EV_BASE, path, 2, distance_table[0][city], -1.0,
               0, city, 1);
  }

  for (int size = 2; size <= cities_after_start; size++) {
    for (int mask = 1; mask < state_count; mask++) {
      if (popcount((unsigned int)mask) != size) continue;
      for (int city = 1; city < n; city++) {
        int city_bit = 1 << (city - 1);
        if (!(mask & city_bit)) continue;
        int previous_mask = mask ^ city_bit;
        double best = INF;
        int best_previous = -1;

        for (int previous = 1; previous < n; previous++) {
          if (!(previous_mask & (1 << (previous - 1)))) continue;
          double candidate = dp[(size_t)previous_mask * n + previous]
                           + distance_table[previous][city];
          int path[MAX_N + 1];
          int length = reconstruct_path(previous_mask, previous, n, parent, path);
          path[length++] = city;
          int updated = candidate + 1e-9 < best;
          if (updated) {
            best = candidate;
            best_previous = previous;
          }
          run->transitions++;
          push_event(run, EV_TRANSITION, path, length, candidate, best,
                     previous, city, updated);
        }

        dp[(size_t)mask * n + city] = best;
        parent[(size_t)mask * n + city] = best_previous;
        run->states++;
      }
    }
  }

  int full_mask = state_count - 1;
  double optimum = INF;
  int final_city = -1;
  for (int city = 1; city < n; city++) {
    double candidate = dp[(size_t)full_mask * n + city] + distance_table[city][0];
    int path[MAX_N + 1];
    int length = reconstruct_path(full_mask, city, n, parent, path);
    path[length++] = 0;
    int updated = candidate + 1e-9 < optimum;
    if (updated) {
      optimum = candidate;
      final_city = city;
    }
    push_event(run, EV_FINISH, path, length, candidate, optimum,
               city, 0, updated);
  }

  int route[MAX_N + 1];
  int route_len = reconstruct_path(full_mask, final_city, n, parent, route);
  route[route_len++] = 0;
  run->best_distance = optimum;
  run->best_route_len = route_len;
  for (int i = 0; i < route_len; i++) run->best_route[i] = route[i];
  run->workspace_bytes = (unsigned long)(cells *
    (sizeof(double) + sizeof(int)));
  push_event(run, EV_SOLUTION, route, route_len, optimum, -1.0,
             final_city, 0, 1);

  clock_t finished = clock();
  run->elapsed_ms = 1000.0 * (double)(finished - started) / (double)CLOCKS_PER_SEC;
  free(dp);
  free(parent);
}

static void print_path(const int *path, int len) {
  printf("[");
  for (int i = 0; i < len; i++) {
    if (i) printf(",");
    printf("%d", path[i]);
  }
  printf("]");
}

static void print_number(double value) {
  if (!isfinite(value) || value < 0.0) printf("null");
  else printf("%.6f", value);
}

static void print_run(const char *name, const Run *run) {
  printf("\"%s\":{\"elapsed_ms\":", name);
  print_number(run->elapsed_ms);
  printf(",\"workspace_bytes\":%lu,\"expanded\":%d,\"pruned\":%d,"
         "\"transitions\":%d,\"states\":%d,\"best_distance\":",
         run->workspace_bytes, run->expanded, run->pruned,
         run->transitions, run->states);
  print_number(run->best_distance);
  printf(",\"best_route\":");
  print_path(run->best_route, run->best_route_len);
  printf(",\"events\":[");
  for (int i = 0; i < run->event_count; i++) {
    const Event *event = &run->events[i];
    if (i) printf(",");
    printf("{\"type\":\"%s\",\"path\":", event_name(event->type));
    print_path(event->path, event->len);
    printf(",\"cost\":");
    print_number(event->cost);
    printf(",\"bound\":");
    print_number(event->bound);
    printf(",\"from\":%d,\"to\":%d,\"updated\":%s}",
           event->from, event->to, event->updated ? "true" : "false");
  }
  printf("]}");
}

static void prepare_distances(int n) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      double dx = (CITIES[i].x - CITIES[j].x) / 10.0;
      double dy = (CITIES[i].y - CITIES[j].y) / 10.0;
      distance_table[i][j] = hypot(dx, dy);
    }
  }
}

int main(void) {
  printf("{\"engine\":\"C\",\"distance_model\":\"Euclidean\",\"cities\":[");
  for (int i = 0; i < MAX_N; i++) {
    if (i) printf(",");
    printf("{\"name\":\"%s\",\"x\":%.1f,\"y\":%.1f}",
           CITIES[i].name, CITIES[i].x, CITIES[i].y);
  }
  printf("],\"cases\":[");

  for (int n = 5; n <= MAX_N; n++) {
    prepare_distances(n);
    solve_branch_bound(n, &branch_run);
    solve_dynamic_programming(n, &dp_run);
    if (fabs(branch_run.best_distance - dp_run.best_distance) > 1e-6) {
      fprintf(stderr, "solver mismatch for %d cities\n", n);
      return 3;
    }
    if (n > 5) printf(",");
    printf("{\"n\":%d,", n);
    print_run("branch_bound", &branch_run);
    printf(",");
    print_run("dynamic_programming", &dp_run);
    printf("}");
  }
  printf("]}\n");
  return 0;
}

