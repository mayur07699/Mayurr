# TSP Lab

A static educational site that replays Branch and Bound and Held–Karp Dynamic Programming traces for 5–9 cities.

## Build the trace data

The algorithms in `src/tsp_algorithms.c` run in native C. Build the site data with:

```sh
./scripts/build-demo.sh
```

The C program computes both algorithms for each city count, checks that their optimal tour lengths agree, and writes browser-readable event traces to `dist/demo-data.json`. The page replays those operations so a learner can step through or compare both searches.

The site is buildless HTML, CSS, and JavaScript after trace generation. No network services or third-party browser libraries are required.

## Complexity

- Branch and Bound: worst-case `O(n!)` time; depth-first working space `O(n)`.
- Held–Karp Dynamic Programming: `O(n² · 2ⁿ)` time and `O(n · 2ⁿ)` space.

The run-time and working-space figures shown in the page describe one C trace-generation run. They are educational measurements, not portable benchmark claims.

