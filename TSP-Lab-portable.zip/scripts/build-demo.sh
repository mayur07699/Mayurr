#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$project_root/dist"
binary_path="$(mktemp /tmp/tsp-c-generator.XXXXXX)"
trap 'rm -f "$binary_path"' EXIT
gcc -std=c99 -O2 -Wall -Wextra -pedantic "$project_root/src/tsp_algorithms.c" -lm -o "$binary_path"
"$binary_path" > "$project_root/dist/demo-data.json"
cp "$project_root/src/tsp_algorithms.c" "$project_root/dist/tsp_algorithms.c"

